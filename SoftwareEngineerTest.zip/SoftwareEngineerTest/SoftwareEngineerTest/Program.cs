﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftwareEngineerTest
{
    class Program
    {
        static void Main(string[] args)
        {
            //Variable for storing range value
            int first;
            int second;
 
            Console.WriteLine("Enter first number");
            first = Convert.ToInt32(Console.ReadLine());  //Accepting and holding values in first variable
            Console.WriteLine("Enter second number");
            second = Convert.ToInt32(Console.ReadLine()); //Accepting and holding values in second variable

            Console.WriteLine();
            Console.Write("Result: ");

            fizz list = new fizz();
            var fizzlist = new List<string>();
            if (first < second)
            {
                for (int i = first; i < second + 1; i++)
                {
                    //If the input number is a multiple of 3 and 5 then output “fizzbuzz”
                    if (i % 3 == 0 && i % 5 == 0)
                    {
                        fizzlist.Add("fizzbuzz"); //Add fizzbuzz value to fizz property 
                        list.FizzBuzz++; 
                        Console.Write("fizzbuzz ");
                    }
                    //If the input number is a multiple of 3 then output “fizz”
                    else if (i % 3 == 0)
                    {
                        fizzlist.Add("Fizz"); //Add fizz value to fizz property
                        list.Fizz++;
                        Console.Write("fizz ");
                    }
                    //If the input number is a multiple of 5 then output “buzz”
                    else if (i % 5 == 0)
                    {
                        fizzlist.Add("buzz"); //Add buzz value to fizz property
                        list.Buzz++;
                        Console.Write("buzz ");
                    }
                    //If no rule matches, then output the input number
                    else if (i % 3 != 0 && i % 5 != 0)
                    {
                        fizzlist.Add(i.ToString());//Add integer value to fizz property
                        list.integer++;
                        Console.Write( i + " ");
                    }
                }
                Console.WriteLine();
                //Display summary 
                Console.WriteLine("Summary: fizz:{0}, buzz:{1}, fizzbuzz:{2}, integer:{3}", list.Fizz, list.Buzz, list.FizzBuzz, list.integer);
            }           
            Console.ReadLine();
        }
    }
}




