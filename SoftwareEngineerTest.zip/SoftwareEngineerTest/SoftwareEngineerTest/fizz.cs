﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoftwareEngineerTest
{
    public class fizz
    {      
        public string Result { get; set; }
        public int Fizz { get; set; }
        public int Buzz { get; set; }
        public int FizzBuzz { get; set; }
        public int integer { get; set; }
    }
   
}


